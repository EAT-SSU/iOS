//
//  MainMapViewController.swift
//  EATSSU-DEV
//
//  Created by 황상환 on 6/24/25.
//

import UIKit

import NMapsMap
import Moya

import EATSSUDesign

final class MainMapViewController: UIViewController {

    private let mainView = MainMapView()
    
    private let partnershipProvider = MoyaProvider<PartnershipRouter>(session: Session(interceptor: AuthInterceptor.shared))
    private var markers: [NMFMarker] = []

    override func loadView() {
        self.view = mainView
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "제휴 지도"

        // 배경색 채우기
        let navBarAppearance = UINavigationBarAppearance()
        navBarAppearance.configureWithOpaqueBackground()
        navBarAppearance.backgroundColor = .white 
        navBarAppearance.titleTextAttributes = [
            .foregroundColor: UIColor.black,
            .font: EATSSUDesignFontFamily.Pretendard.bold.font(size: 16)
        ]

        navigationController?.navigationBar.standardAppearance = navBarAppearance
        navigationController?.navigationBar.scrollEdgeAppearance = navBarAppearance
        navigationController?.navigationBar.compactAppearance = navBarAppearance

        mainView.wholeButton.addTarget(self, action: #selector(didTapWhole), for: .touchUpInside)
        mainView.myOnlyButton.addTarget(self, action: #selector(didTapMyOnly), for: .touchUpInside)
        mainView.heartButton.addTarget(self, action: #selector(didTapHeart), for: .touchUpInside)
        
        fetchPartnerships()
    }

    @objc private func didTapWhole() {
        mainView.selectWhole(true)
        print("전체 보기")
    }

    @objc private func didTapMyOnly() {
        mainView.selectWhole(false)
        print("내 제휴 보기")
    }

    @objc private func didTapHeart() {
        print("하트 버튼 클릭됨")
    }
    
    private func displayMarkers(_ partnerships: [PartnershipDTO]) {
        markers.forEach { $0.mapView = nil }
        markers.removeAll()

        var latSum: Double = 0
        var lngSum: Double = 0

        for partnership in partnerships {
            let marker = NMFMarker()
            marker.position = NMGLatLng(lat: partnership.latitude, lng: partnership.longitude)
            
            let markerImage = makeMarkerImage(type: partnership.restaurantType, title: partnership.storeName)
            marker.iconImage = NMFOverlayImage(image: markerImage)
            marker.width = CGFloat(UInt32(markerImage.size.width))
            marker.height = CGFloat(UInt32(markerImage.size.height))
            
            marker.touchHandler = { [weak self] _ in
               let vc = PartnershipDetailSheetViewController(partnership: partnership)
               self?.present(vc, animated: true)
               return true
           }
            
            marker.mapView = mainView.mapView.mapView
            markers.append(marker)

            latSum += partnership.latitude
            lngSum += partnership.longitude
        }

        if !partnerships.isEmpty {
            let centerLat = latSum / Double(partnerships.count)
            let centerLng = lngSum / Double(partnerships.count)
            let cameraUpdate = NMFCameraUpdate(scrollTo: NMGLatLng(lat: centerLat, lng: centerLng))
            mainView.mapView.mapView.moveCamera(cameraUpdate)
        }
    }

    private func makeMarkerImage(type: String, title: String) -> UIImage {
        let icon: UIImage?

        switch type {
        case "RESTAURANT":
            icon = EATSSUDesignAsset.Images.restaurantPin.image
        case "CAFE":
            icon = EATSSUDesignAsset.Images.cafePin.image
        case "PUB":
            icon = EATSSUDesignAsset.Images.pubPin.image
        default:
            icon = EATSSUDesignAsset.Images.restaurantPin.image
        }

        let markerView = MapMarkerView(icon: icon, title: title)
        markerView.setNeedsLayout()
        markerView.layoutIfNeeded()

        let fittingSize = markerView.systemLayoutSizeFitting(
            CGSize(width: UIView.layoutFittingCompressedSize.width, height: 24),
            withHorizontalFittingPriority: .fittingSizeLevel,
            verticalFittingPriority: .required
        )

        markerView.frame = CGRect(origin: .zero, size: fittingSize)
        return markerView.toImage()

    }

    // MARK: - Network

    private func fetchPartnerships() {
        partnershipProvider.request(.getAllPartnerships) { [weak self] result in
            switch result {
            case .success(let response):
                do {
                    let decoded = try response.map(BaseResponse<[PartnershipDTO]>.self)
                    guard let partnerships = decoded.result else { return }
                    self?.displayMarkers(partnerships)
                } catch {
                    print("Decoding 실패: \(error.localizedDescription)")
                }
            case .failure(let error):
                print("네트워크 오류: \(error.localizedDescription)")
            }
        }
    }
}
