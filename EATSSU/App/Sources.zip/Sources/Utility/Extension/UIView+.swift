//
//  UIView+.swift
//  EatSSU-iOS
//
//  Created by 박윤빈 on 2023/03/15.
//

import Foundation
import UIKit

extension UIView {
    func addSubviews(_ views: UIView...) {
        views.forEach { self.addSubview($0) }
    }

    func roundCorners(corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        layer.mask = mask
    }
}

public extension UIView {
    /// 파라미터로 입력받은 문자열을 토스트 메시지를 전달합니다.
    ///
    /// - Parameters:
    /// 	- message: 토스트 메시지로 전달할 문자열
    func showToast(message: String) {
        let toastLabel = UILabel()
        toastLabel.numberOfLines = 2
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        toastLabel.textColor = UIColor.white
        toastLabel.textAlignment = .center
        toastLabel.font = UIFont(name: "Montserrat-Light", size: 12.0)
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10
        toastLabel.clipsToBounds = true

        let toastWidth = toastLabel.intrinsicContentSize.width + 20
        let toastHeight = toastLabel.intrinsicContentSize.height + 10
        toastLabel.frame = CGRect(x: frame.size.width / 2 - toastWidth / 2,
                                  y: frame.size.height - toastHeight - 30,
                                  width: toastWidth,
                                  height: toastHeight)
        addSubview(toastLabel)

        UIView.animate(withDuration: 1.6, delay: 0.6, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: { _ in
            toastLabel.removeFromSuperview()
        })
    }
}
